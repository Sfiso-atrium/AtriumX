type IconProps = {
  size?: number
  className?: string
}

export default function HomeIcon({ size = 24, className }: IconProps) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" className={className}>
      <path d="M0 0h24v24H0z" fill="none" />
      <path fill="currentColor" d="M12 3L2 12h3v8h6v-6h2v6h6v-8h3zm5 15h-2v-6H9v6H7v-7.81l5-4.5l5 4.5z" />
      <path fill="currentColor" d="M7 10.19V18h2v-6h6v6h2v-7.81l-5-4.5z" opacity=".3" />
    </svg>
  )
}
